# 🚍 AI for Equitable Public Transportation

> Predicting transit access gaps and equity issues across Miami-Dade County using AI-driven demand forecasting, scenario simulation, and interactive visualization.

[![Status](https://img.shields.io/badge/Status-Sprint%201-yellow)]()
[![Python](https://img.shields.io/badge/Python-3.10+-blue)]()
[![License](https://img.shields.io/badge/License-MIT-green)]()

**Capstone Project** — University of Miami × Deloitte AI Academy  
**Duration:** January 16 – May 1, 2026

## 📋 Problem Statement

Urban public transportation systems face persistent equity challenges: uneven service coverage, long wait times in underserved areas, and limited visibility into how demographic changes impact access. These challenges are especially relevant in Miami-Dade County, where population density, income distribution, and transit dependency vary significantly across neighborhoods.

This project aims to design an AI-driven decision support system that identifies transit accessibility gaps, predicts emerging inequities, and evaluates the impact of potential service changes through lightweight what-if simulations.

**Industry Focus:** Demand Forecasting · Universal Service Design · Accessibility

## 🎯 Project Goals

1. **Identify** current and future public transportation access gaps
2. **Predict** changes in transit demand and equity outcomes using interpretable models
3. **Simulate** lightweight "what-if" scenarios for service modifications
4. **Visualize** insights through an interactive dashboard
5. **Support** data-driven, equity-focused transit planning decisions

## 📦 Deliverables

| Sprint | Deliverable | Description |
|---|---|---|
| Sprint 1 | **Exploratory Data Analysis** | Cleaned dataset, data dictionary, EDA report with hypotheses |
| Sprint 2 | **Predictive Models** | Baseline regression & time series models with geographic prioritization |
| Sprint 3 | **Simulation + Dashboard** | What-if scenario engine and interactive Streamlit/Power BI dashboard |
| Sprint 4–5 | **Final Presentation** | Polished narrative, live demo, and policy recommendations |

## 📊 Data Sources

| Dataset | Source | Description |
|---|---|---|
| Demographic Data | [US Census Bureau (ACS 2023)](https://data.census.gov/table/ACSDP1Y2023.DP03?q=DP03&g=040XX00US12) | Socioeconomic and demographic profiles for Florida |
| Transit System Data | [GTFS](https://gtfs.org/) | Schedule and real-time transit feeds |
| Accessibility Data | [National Accessibility Evaluation](https://www.arcgis.com/home/item.html?id=40526f1e2c734241bab4d3bb41385c51) | Transit accessibility metrics via ArcGIS |

## 🛠️ Tech Stack

| Category | Tools |
|---|---|
| Data Processing | Python (Pandas, NumPy, GeoPandas) |
| Modeling | Scikit-learn, Statsmodels, Interpretable ML |
| Visualization | Plotly, Folium/Mapbox, Matplotlib, Seaborn |
| Dashboard | Streamlit or Power BI |
| Simulation | Custom Python (parameter-based what-if scenarios) |
| Project Tracking | Notion |
| Version Control | Git / GitHub |

## 🚀 Getting Started

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/CapstoneProject-AI-for-Equitable-Transportation.git
cd CapstoneProject-AI-for-Equitable-Transportation

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

## 📁 Project Structure

```
├── data/
│   ├── raw/                  # Original datasets (Census, GTFS, Accessibility)
│   │   ├── census/
│   │   ├── gtfs/
│   │   └── accessibility/
│   ├── interim/              # Intermediate transformations
│   └── processed/            # Final cleaned & merged datasets
├── notebooks/                # Jupyter notebooks (EDA, modeling, simulation)
├── src/
│   ├── data/                 # Data loading, cleaning, merging scripts
│   ├── features/             # Feature engineering pipeline
│   ├── models/               # Model training, evaluation, interpretation
│   ├── simulation/           # What-if scenario logic
│   └── visualization/        # Plotting and map utilities
├── dashboard/                # Streamlit / Power BI app
├── reports/
│   ├── figures/              # Generated charts and maps
│   └── sprint_reviews/       # Sprint review presentations
├── docs/                     # Data dictionary, methodology docs
├── tests/                    # Unit tests
├── requirements.txt
├── .gitignore
└── README.md
```

## 📅 Sprint Timeline

```
Sprint 1 ▸ EDA                    Jan 16 – Feb 20  ██████████░░░░░░░░░░ 
Sprint 2 ▸ Modeling               Feb 21 – Mar 27  ░░░░░░░░░░██████████
Sprint 3 ▸ Simulation + Dashboard Mar 28 – Apr 17  ░░░░░░░░░░░░░░██████
Sprint 4 ▸ Dry-Run               Apr 18 – Apr 24  ░░░░░░░░░░░░░░░░░░██
Sprint 5 ▸ Final Presentation    May 1             ░░░░░░░░░░░░░░░░░░░█
```

## 👥 Team

| Name | Role |
|---|---|
| Daniel Regalado | Team Member |
| Luna Gerlic | Team Member |
| Jeanne Hassoun | Team Member |
| Lina Graf | Team Member |
| Amelia Simpson | Team Member |

## 📝 Guiding Principles

- **Don't overcommit** — deliver what we promise, promise what we can deliver
- **AI ≠ just LLMs** — leverage regression, time series, clustering, spatial analysis
- **MVP first** — a working, interpretable pipeline beats an ambitious but unfinished system
- **Let data guide decisions** — evaluate early, pivot if needed
- **Stay curious** — ask questions and clarify assumptions continuously

---

*University of Miami — MS in Business Analytics — Deloitte AI Academy Capstone 2026*
